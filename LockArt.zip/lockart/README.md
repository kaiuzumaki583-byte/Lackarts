# LockArt

Shows the album cover of whatever you're playing (Spotify, YouTube Music, etc.) on your
Android lock screen, in the style of the iPhone one: tinted background, big clock,
square cover, player card.

## Build
1. Install Android Studio and open this folder (`lockart`).
2. Let Gradle sync, plug in your phone (USB debugging on) and press Run.

## First-time setup on the phone
1. **Notification access**: lets the app see what's playing. Nothing leaves the phone.
2. **Display over other apps**: lets the lock screen view open by itself when music plays.
3. **Battery: Unrestricted**: stops Samsung/Xiaomi/Tecno/Infinix from killing the app.

## Modes
- **Lock screen view**: a full-screen view over your real lock screen with the clock,
  cover, player card and controls. Swipe up to unlock (your PIN/fingerprint still applies).
  Appears when a song starts while locked, and when you wake the screen during playback.
- **Wallpaper**: paints background + cover into your real lock screen wallpaper whenever
  the song changes. Your phone's own clock and music controls sit on top.

## Options
- Cover only, or cover + player
- Background: tinted from the cover, blurred cover, or your own lock screen photo

## Fonts
Apple's SF Pro font and Apple emoji can't be used in Android apps (Apple's licence), so
they are not included. Free look-alikes from fonts.google.com:
1. Download **Inter** (very close to SF Pro Text) and **Nunito** (rounded, close to the
   clock style). Use the *static* files, not the variable ones.
2. Copy `Nunito-ExtraBold.ttf` to `app/src/main/res/font/clock.ttf`
3. Copy `Inter-Regular.ttf` to `app/src/main/res/font/ui.ttf`
   (file names must be lowercase). Rebuild. Without these files the phone's default font is used.
Emoji use your phone's normal emoji set.

## Extras
- **Caption**: type any line (e.g. "something good") and it shows under the cover.
- **Notifications**: your real notifications appear as cards (needs notification access).
- **My own message card**: you write the name, title, text and upload the icon and picture
  yourself; it shows like a notification. Nothing from other companies is bundled.
- **My current wallpaper** background: your normal wallpaper shows behind the cover. Some
  phones show the home wallpaper instead of the lock one here; use "My own lock screen
  photo" if yours does.

## Checking it works
1. Run the app, grant the 3 permissions, play a song in Spotify/YouTube Music.
2. Open LockArt, tap **Preview lock screen**: cover, title and progress should match.
3. Lock the phone, wait a few seconds, press the power button: the view should appear.
4. Change song: cover updates. Tap pause/next on the card: the music app reacts.
5. Nothing shows when locked? Check battery = Unrestricted, and the 3 permissions.

## Limits
- Android can't replace the system lock screen, so the lock screen view is an overlay
  over it. It won't match the iPhone pixel for pixel.
- Some music apps don't send album art; the app then shows no cover.

## Get an installable APK without Android Studio
1. Make a free account at github.com, create a new repository, and upload the contents of
   this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab, wait for "Build APK" to finish (about 5 minutes).
3. Open the finished run, download **LockArt-apk**, unzip it to get `app-debug.apk`.
4. Open the APK on your phone and allow "Install unknown apps" when asked.
