package com.example.lockart

import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.flow.MutableStateFlow

/** Shared "what's playing now" state, written by MediaListenerService and read by the UI. */
object MediaState {
    data class Track(
        val title: String,
        val artist: String,
        val art: Bitmap?,
        val playing: Boolean,
        val position: Long,      // ms, at updateTime
        val updateTime: Long,    // SystemClock.elapsedRealtime() when position was sampled
        val speed: Float,
        val duration: Long       // ms, 0 if unknown
    )

    /** A real notification from another app, shown on the lock screen view. */
    data class Notif(val key: String, val app: String, val title: String, val text: String, val time: Long)

    val track = MutableStateFlow<Track?>(null)
    val notifications = MutableStateFlow<List<Notif>>(emptyList())

    @Volatile
    var controller: MediaController? = null
}
