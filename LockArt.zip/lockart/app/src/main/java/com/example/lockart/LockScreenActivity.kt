package com.example.lockart

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Bundle
import android.os.SystemClock
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Fonts are optional files you add yourself (see README):
 *   app/src/main/res/font/clock.ttf  -> clock and date
 *   app/src/main/res/font/ui.ttf     -> everything else
 * If a file is missing, the phone's default sans-serif is used.
 */
@Composable
private fun rememberFont(name: String, weight: FontWeight): FontFamily {
    val ctx = LocalContext.current
    return remember(name) {
        val id = ctx.resources.getIdentifier(name, "font", ctx.packageName)
        if (id != 0) FontFamily(Font(id, weight)) else FontFamily.SansSerif
    }
}

class LockScreenActivity : ComponentActivity() {

    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this, unlocked, IntentFilter(Intent.ACTION_USER_PRESENT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        val prefs = Prefs(this)
        setContent { LockScreen(prefs, onUnlock = ::unlock) }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(unlocked) }
        super.onDestroy()
    }

    private fun unlock() {
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() = finish()
            })
        } else finish()
    }
}

@Composable
private fun ticker(): State<Long> = produceState(SystemClock.elapsedRealtime()) {
    while (true) {
        value = SystemClock.elapsedRealtime()
        delay(1000)
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun LockScreen(prefs: Prefs, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val track by MediaState.track.collectAsState()
    val notifs by MediaState.notifications.collectAsState()
    val nowElapsed by ticker()
    val t = track
    val art = t?.art
    val clockFont = rememberFont("clock", FontWeight.Bold)
    val uiFont = rememberFont("ui", FontWeight.Normal)

    val tint = remember(art) { art?.let { Color(Art.tintColor(it)) } ?: Color(0xFF151515) }
    val photo = remember(prefs.photoUri) { Art.loadPhoto(ctx, prefs.photoUri) }
    val msgIcon = remember(prefs.msgIconUri) { Art.loadPhoto(ctx, prefs.msgIconUri) }
    val msgImage = remember(prefs.msgImageUri) { Art.loadPhoto(ctx, prefs.msgImageUri) }

    val is24 = DateFormat.is24HourFormat(ctx)
    val timeText = remember(nowElapsed / 15000) {
        SimpleDateFormat(if (is24) "H:mm" else "h:mm", Locale.getDefault()).format(Date())
    }
    val dateText = remember(nowElapsed / 15000) {
        SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
    }

    val showMsg = prefs.msgEnabled && (prefs.msgTitle.isNotBlank() || prefs.msgText.isNotBlank())
    val shownNotifs = if (prefs.showNotifications) notifs.take(if (showMsg) 2 else 3) else emptyList()
    val hasExtras = showMsg || shownNotifs.isNotEmpty()

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -250f) onUnlock() },
                    onDragCancel = { },
                    onVerticalDrag = { _, d -> total += d }
                )
            }
    ) {
        // ---- Background ----
        when {
            prefs.background == Background.WALLPAPER -> {
                // Draw nothing: your wallpaper shows through. Slight dim keeps text readable.
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.12f)))
            }
            prefs.background == Background.PHOTO && photo != null -> {
                Image(photo.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)))
            }
            prefs.background == Background.BLUR && art != null -> {
                Image(
                    art.asImageBitmap(), null,
                    Modifier.fillMaxSize().blur(80.dp),
                    contentScale = ContentScale.Crop
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))
            }
            else -> Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(tint, Color(tint.red * 0.7f, tint.green * 0.7f, tint.blue * 0.7f))
                    )
                )
            )
        }

        // ---- Content ----
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(36.dp))
                Text(
                    dateText,
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = clockFont
                )
                Text(
                    timeText,
                    color = Color.White.copy(alpha = 0.82f),
                    fontSize = 118.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = clockFont,
                    letterSpacing = (-3).sp
                )
                Spacer(Modifier.height(12.dp))

                // Cover (smaller when there are cards underneath so everything fits)
                if (art != null) {
                    Image(
                        art.asImageBitmap(), null,
                        Modifier
                            .fillMaxWidth(if (hasExtras) 0.62f else 1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        "Play a song to see its cover",
                        color = Color.White.copy(alpha = 0.6f),
                        fontFamily = uiFont,
                        modifier = Modifier.padding(top = 60.dp)
                    )
                }

                // Caption you typed
                if (prefs.caption.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        prefs.caption,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = uiFont,
                        textAlign = TextAlign.Center
                    )
                }

                // Player card (hidden in "art only" layout)
                if (prefs.layout == Layout.FULL && t != null) {
                    Spacer(Modifier.height(20.dp))
                    PlayerCard(t, nowElapsed, uiFont)
                }

                // Your custom message card
                if (showMsg) {
                    Spacer(Modifier.height(14.dp))
                    NotifCard(
                        app = prefs.msgApp, title = prefs.msgTitle, text = prefs.msgText,
                        time = "now", icon = msgIcon, image = msgImage, font = uiFont
                    )
                }

                // Real notifications from your phone
                shownNotifs.forEach { n ->
                    Spacer(Modifier.height(10.dp))
                    val mins = ((System.currentTimeMillis() - n.time) / 60000).toInt()
                    NotifCard(
                        app = n.app, title = n.title, text = n.text,
                        time = if (mins < 1) "now" else "${mins}m ago",
                        icon = null, image = null, font = uiFont
                    )
                }
                Spacer(Modifier.height(16.dp))
            }

            Box(
                Modifier
                    .padding(top = 8.dp, bottom = 8.dp)
                    .clickable { onUnlock() }
                    .width(140.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.9f))
            )
        }
    }
}

@Composable
private fun NotifCard(
    app: String, title: String, text: String, time: String,
    icon: Bitmap?, image: Bitmap?, font: FontFamily
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.2f))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App icon: your uploaded icon, or the app's first letter
        if (icon != null) {
            Image(
                icon.asImageBitmap(), null,
                Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    app.take(1).uppercase(), color = Color.White, fontFamily = font,
                    fontWeight = FontWeight.Bold, fontSize = 18.sp
                )
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    title.ifBlank { app }, color = Color.White, fontFamily = font,
                    fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text(
                    time, color = Color.White.copy(alpha = 0.6f), fontFamily = font, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            if (text.isNotBlank()) {
                Text(
                    text, color = Color.White.copy(alpha = 0.85f), fontFamily = font, fontSize = 15.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (image != null) {
            Image(
                image.asImageBitmap(), null,
                Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Composable
private fun PlayerCard(t: MediaState.Track, nowElapsed: Long, font: FontFamily) {
    val pos = if (t.playing)
        (t.position + ((nowElapsed - t.updateTime) * t.speed).toLong())
    else t.position
    val clamped = if (t.duration > 0) pos.coerceIn(0, t.duration) else pos
    val progress = if (t.duration > 0) clamped.toFloat() / t.duration else 0f
    val controls = MediaState.controller?.transportControls

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.25f))
            .padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Text(
            t.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Medium,
            fontFamily = font, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Text(
            t.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 19.sp,
            fontFamily = font, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(14.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
            color = Color.White.copy(alpha = 0.85f),
            trackColor = Color.White.copy(alpha = 0.2f),
        )
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(clamped), color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, fontFamily = font)
            if (t.duration > 0)
                Text(
                    "-" + fmt(t.duration - clamped),
                    color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, fontFamily = font
                )
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { controls?.skipToPrevious() }, Modifier.size(64.dp)) {
                Icon(Icons.Filled.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(44.dp))
            }
            IconButton(
                onClick = { if (t.playing) controls?.pause() else controls?.play() },
                Modifier.size(72.dp)
            ) {
                Icon(
                    if (t.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    "Play/Pause", tint = Color.White, modifier = Modifier.size(56.dp)
                )
            }
            IconButton(onClick = { controls?.skipToNext() }, Modifier.size(64.dp)) {
                Icon(Icons.Filled.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(44.dp))
            }
        }
    }
}
