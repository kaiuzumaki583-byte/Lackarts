package com.example.lockart

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette

/** Helpers shared by the overlay screen and the wallpaper mode. */
object Art {
    /** A dark version of the cover's main colour, like the tinted background in the screenshot. */
    fun tintColor(art: Bitmap): Int {
        val p = Palette.from(art).generate()
        val base = p.getDarkVibrantColor(p.getDominantColor(0xFF222222.toInt()))
        return ColorUtils.blendARGB(base, Color.BLACK, 0.35f)
    }

    fun loadPhoto(ctx: Context, uri: String?): Bitmap? {
        if (uri == null) return null
        return runCatching {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }
}

/**
 * Wallpaper mode: paints "background + square cover" into the lock screen wallpaper.
 * The phone's own clock, date and music controls sit on top of it, so this works on
 * every Android phone without any overlay tricks. The cover is placed where the
 * iPhone puts it, just under the clock.
 */
object WallpaperApplier {
    fun apply(ctx: Context, art: Bitmap, prefs: Prefs) {
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        // Background
        val photo = if (prefs.background == Background.PHOTO) Art.loadPhoto(ctx, prefs.photoUri) else null
        when {
            photo != null -> {
                drawCropped(canvas, photo, w, h)
                canvas.drawColor(Color.argb(60, 0, 0, 0))
            }
            prefs.background == Background.BLUR -> {
                // Cheap blur: shrink the cover and stretch it back up with filtering.
                val tiny = Bitmap.createScaledBitmap(art, 16, 16, true)
                drawCropped(canvas, tiny, w, h)
                canvas.drawColor(Color.argb(120, 0, 0, 0))
            }
            else -> canvas.drawColor(Art.tintColor(art))
        }

        // Cover, rounded, ~84% of the width, starting ~27% down the screen
        val size = w * 0.84f
        val left = (w - size) / 2f
        val top = h * 0.27f
        val rect = RectF(left, top, left + size, top + size)
        val radius = size * 0.035f
        canvas.save()
        canvas.clipPath(Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) })
        canvas.drawBitmap(art, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        canvas.restore()

        WallpaperManager.getInstance(ctx)
            .setBitmap(out, null, true, WallpaperManager.FLAG_LOCK)
    }

    private fun drawCropped(canvas: Canvas, src: Bitmap, w: Int, h: Int) {
        val scale = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val sw = src.width * scale
        val sh = src.height * scale
        val dst = RectF((w - sw) / 2f, (h - sh) / 2f, (w + sw) / 2f, (h + sh) / 2f)
        canvas.drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
    }
}
