package com.example.lockart

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlin.concurrent.thread

/**
 * Reads whatever music app is playing (Spotify, YouTube Music, ...) through its media session.
 * Needs "Notification access" turned on for this app. Nothing leaves the phone.
 */
class MediaListenerService : NotificationListenerService() {

    private lateinit var msm: MediaSessionManager
    private lateinit var self: ComponentName
    private var current: MediaController? = null
    private var lastTitle: String? = null
    private var lastPlaying = false

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = pick(safeSessions())
    }

    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (MediaState.track.value?.playing == true) showOverlayIfLocked()
        }
    }

    override fun onListenerConnected() {
        self = ComponentName(this, MediaListenerService::class.java)
        msm = getSystemService(MediaSessionManager::class.java)
        msm.addOnActiveSessionsChangedListener(sessionsListener, self)
        registerReceiver(screenOn, IntentFilter(Intent.ACTION_SCREEN_ON), RECEIVER_NOT_EXPORTED)
        pick(safeSessions())
        refreshNotifications()
    }

    override fun onListenerDisconnected() {
        runCatching { msm.removeOnActiveSessionsChangedListener(sessionsListener) }
        runCatching { unregisterReceiver(screenOn) }
        current?.unregisterCallback(callback)
        current = null
        MediaState.controller = null
        MediaState.track.value = null
    }

    // ---- Real notifications ----
    override fun onNotificationPosted(sbn: StatusBarNotification) = refreshNotifications()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refreshNotifications()

    private fun refreshNotifications() {
        val list = runCatching { activeNotifications }.getOrNull().orEmpty()
            .filter { it.packageName != packageName }
            .filter { it.isClearable }
            .filter { it.notification.category != Notification.CATEGORY_TRANSPORT }
            .filter { it.notification.flags and Notification.FLAG_GROUP_SUMMARY == 0 }
            .mapNotNull { sbn ->
                val extras = sbn.notification.extras
                val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
                if (title.isEmpty() && text.isEmpty()) return@mapNotNull null
                val app = runCatching {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
                }.getOrDefault(sbn.packageName)
                MediaState.Notif(sbn.key, app, title, text, sbn.postTime)
            }
            .sortedByDescending { it.time }
            .take(4)
        MediaState.notifications.value = list
    }

    private fun safeSessions(): List<MediaController> =
        runCatching { msm.getActiveSessions(self) }.getOrDefault(emptyList())

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (best?.sessionToken != current?.sessionToken) {
            current?.unregisterCallback(callback)
            current = best
            MediaState.controller = best
            best?.registerCallback(callback)
        }
        publish()
    }

    private fun publish() {
        val c = current
        val md = c?.metadata
        if (c == null || md == null) {
            MediaState.track.value = null
            return
        }
        val title = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown"
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val ps = c.playbackState
        val playing = ps?.state == PlaybackState.STATE_PLAYING

        val track = MediaState.Track(
            title = title,
            artist = artist,
            art = art,
            playing = playing,
            position = ps?.position ?: 0L,
            updateTime = ps?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
            speed = ps?.playbackSpeed ?: 1f,
            duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        )
        MediaState.track.value = track

        val changed = title != lastTitle || (playing && !lastPlaying)
        lastTitle = title
        lastPlaying = playing
        if (changed && playing) onTrackStarted(track)
    }

    private fun onTrackStarted(t: MediaState.Track) {
        val prefs = Prefs(this)
        when (prefs.mode) {
            Mode.OVERLAY -> showOverlayIfLocked()
            Mode.WALLPAPER -> if (t.art != null) {
                val app = applicationContext
                thread { runCatching { WallpaperApplier.apply(app, t.art, prefs) } }
            }
        }
    }

    private fun showOverlayIfLocked() {
        if (Prefs(this).mode != Mode.OVERLAY) return
        if (!Settings.canDrawOverlays(this)) return
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) return
        startActivity(
            Intent(this, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
    }
}
