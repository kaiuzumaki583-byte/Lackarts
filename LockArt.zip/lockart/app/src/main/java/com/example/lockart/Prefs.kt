package com.example.lockart

import android.content.Context

/** Mode: how the art gets onto the lock screen. */
object Mode { const val OVERLAY = "OVERLAY"; const val WALLPAPER = "WALLPAPER" }

/** Layout: art only, or art + player card (title, progress, controls). */
object Layout { const val ART_ONLY = "ART_ONLY"; const val FULL = "FULL" }

/** Background behind the art. */
object Background {
    const val TINT = "TINT"; const val BLUR = "BLUR"; const val PHOTO = "PHOTO"
    /** Nothing drawn: your normal wallpaper shows through behind the cover. */
    const val WALLPAPER = "WALLPAPER"
}

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("lockart", Context.MODE_PRIVATE)

    var mode: String
        get() = sp.getString("mode", Mode.OVERLAY)!!
        set(v) = sp.edit().putString("mode", v).apply()

    var layout: String
        get() = sp.getString("layout", Layout.FULL)!!
        set(v) = sp.edit().putString("layout", v).apply()

    var background: String
        get() = sp.getString("background", Background.TINT)!!
        set(v) = sp.edit().putString("background", v).apply()

    /** Your own lock screen photo (content:// uri), used when background == PHOTO. */
    var photoUri: String?
        get() = sp.getString("photoUri", null)
        set(v) = sp.edit().putString("photoUri", v).apply()

    /** Short line you type, shown under the cover ("something good"). */
    var caption: String
        get() = sp.getString("caption", "")!!
        set(v) = sp.edit().putString("caption", v).apply()

    /** Show your phone's real notifications on the lock screen view. */
    var showNotifications: Boolean
        get() = sp.getBoolean("showNotifications", true)
        set(v) = sp.edit().putBoolean("showNotifications", v).apply()

    // ---- Custom message card (a card you write yourself) ----
    var msgEnabled: Boolean
        get() = sp.getBoolean("msgEnabled", false)
        set(v) = sp.edit().putBoolean("msgEnabled", v).apply()

    var msgApp: String
        get() = sp.getString("msgApp", "Messages")!!
        set(v) = sp.edit().putString("msgApp", v).apply()

    var msgTitle: String
        get() = sp.getString("msgTitle", "")!!
        set(v) = sp.edit().putString("msgTitle", v).apply()

    var msgText: String
        get() = sp.getString("msgText", "")!!
        set(v) = sp.edit().putString("msgText", v).apply()

    /** Small app icon shown on the card (you upload it). */
    var msgIconUri: String?
        get() = sp.getString("msgIconUri", null)
        set(v) = sp.edit().putString("msgIconUri", v).apply()

    /** Picture shown on the card (you upload it). */
    var msgImageUri: String?
        get() = sp.getString("msgImageUri", null)
        set(v) = sp.edit().putString("msgImageUri", v).apply()
}
