package com.example.lockart

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { SettingsScreen(resumeTick) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

@Composable
private fun SettingsScreen(refresh: Int) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var mode by remember { mutableStateOf(prefs.mode) }
    var layout by remember { mutableStateOf(prefs.layout) }
    var bg by remember { mutableStateOf(prefs.background) }
    var photo by remember { mutableStateOf(prefs.photoUri) }
    var caption by remember { mutableStateOf(prefs.caption) }
    var showNotifs by remember { mutableStateOf(prefs.showNotifications) }
    var msgOn by remember { mutableStateOf(prefs.msgEnabled) }
    var msgApp by remember { mutableStateOf(prefs.msgApp) }
    var msgTitle by remember { mutableStateOf(prefs.msgTitle) }
    var msgText by remember { mutableStateOf(prefs.msgText) }
    var msgIcon by remember { mutableStateOf(prefs.msgIconUri) }
    var msgImage by remember { mutableStateOf(prefs.msgImageUri) }

    val pickMsgIcon = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.msgIconUri = uri.toString(); msgIcon = uri.toString()
        }
    }
    val pickMsgImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.msgImageUri = uri.toString(); msgImage = uri.toString()
        }
    }

    // Re-read permissions whenever the user comes back from system settings
    val hasListener = remember(refresh) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val hasOverlay = remember(refresh) { Settings.canDrawOverlays(ctx) }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.photoUri = uri.toString()
            photo = uri.toString()
            prefs.background = Background.PHOTO
            bg = Background.PHOTO
        }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("LockArt", style = MaterialTheme.typography.headlineMedium)
        Text("Shows your current album cover on the lock screen, iPhone style.")

        Section("1. Permissions")
        Button(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            Modifier.fillMaxWidth()
        ) { Text(if (hasListener) "Notification access: ON" else "Allow notification access (reads what's playing)") }
        Button(
            onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            },
            Modifier.fillMaxWidth()
        ) { Text(if (hasOverlay) "Display over other apps: ON" else "Allow display over other apps") }
        OutlinedButton(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
            Modifier.fillMaxWidth()
        ) { Text("Battery: set LockArt to Unrestricted") }

        Section("2. How should it show?")
        Choice("Lock screen view (clock, cover, player, swipe up to unlock)", mode == Mode.OVERLAY) {
            mode = Mode.OVERLAY; prefs.mode = Mode.OVERLAY
        }
        Choice("Wallpaper (sets the cover as your real lock screen wallpaper)", mode == Mode.WALLPAPER) {
            mode = Mode.WALLPAPER; prefs.mode = Mode.WALLPAPER
        }

        Section("3. What to show")
        Choice("Cover + player (title, progress, controls)", layout == Layout.FULL) {
            layout = Layout.FULL; prefs.layout = Layout.FULL
        }
        Choice("Cover only", layout == Layout.ART_ONLY) {
            layout = Layout.ART_ONLY; prefs.layout = Layout.ART_ONLY
        }

        Section("4. Background")
        Choice("Tinted from the cover colours", bg == Background.TINT) {
            bg = Background.TINT; prefs.background = Background.TINT
        }
        Choice("Blurred cover", bg == Background.BLUR) {
            bg = Background.BLUR; prefs.background = Background.BLUR
        }
        Choice("My current wallpaper (shows behind the cover)", bg == Background.WALLPAPER) {
            bg = Background.WALLPAPER; prefs.background = Background.WALLPAPER
        }
        Choice(
            if (photo == null) "My own lock screen photo" else "My own lock screen photo (selected)",
            bg == Background.PHOTO
        ) {
            if (photo == null) pickPhoto.launch(arrayOf("image/*"))
            else { bg = Background.PHOTO; prefs.background = Background.PHOTO }
        }
        OutlinedButton(onClick = { pickPhoto.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) {
            Text("Choose / change photo")
        }

        Section("5. Caption under the cover")
        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it; prefs.caption = it },
            label = { Text("Type anything (e.g. something good)") },
            modifier = Modifier.fillMaxWidth()
        )

        Section("6. Notifications")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Show my real notifications", Modifier.weight(1f))
            Switch(checked = showNotifs, onCheckedChange = { showNotifs = it; prefs.showNotifications = it })
        }

        Section("7. My own message card")
        Text(
            "A card you write yourself, shown like a notification. You choose the name, icon, text and picture.",
            style = MaterialTheme.typography.bodySmall
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Show the card", Modifier.weight(1f))
            Switch(checked = msgOn, onCheckedChange = { msgOn = it; prefs.msgEnabled = it })
        }
        OutlinedTextField(
            value = msgApp, onValueChange = { msgApp = it; prefs.msgApp = it },
            label = { Text("Name shown on the card") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = msgTitle, onValueChange = { msgTitle = it; prefs.msgTitle = it },
            label = { Text("Title / sender") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = msgText, onValueChange = { msgText = it; prefs.msgText = it },
            label = { Text("Message text") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { pickMsgIcon.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) {
            Text(if (msgIcon == null) "Upload card icon" else "Change card icon (selected)")
        }
        OutlinedButton(onClick = { pickMsgImage.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) {
            Text(if (msgImage == null) "Upload card picture" else "Change card picture (selected)")
        }

        Section("Try it")
        Button(
            onClick = { ctx.startActivity(Intent(ctx, LockScreenActivity::class.java)) },
            Modifier.fillMaxWidth()
        ) { Text("Preview lock screen") }
        Text(
            "Play a song first, then tap Preview. Swipe up on the preview to close it.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 14.dp))
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, Modifier.padding(start = 4.dp))
    }
}
